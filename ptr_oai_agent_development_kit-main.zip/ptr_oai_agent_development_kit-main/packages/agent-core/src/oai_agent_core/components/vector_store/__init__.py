# Vector store components
