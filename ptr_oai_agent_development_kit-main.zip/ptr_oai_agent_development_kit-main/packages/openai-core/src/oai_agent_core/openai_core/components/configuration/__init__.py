"""Configuration components module."""
